#ifndef SCHM_XCP_H
#define SCHM_XCP_H

#include "Os.h"

#define    SchM_Enter_Xcp_SCHM_XCP_EXCLUSIVE_AREA_XCP_INTERNALS()


#define    SchM_Exit_Xcp_SCHM_XCP_EXCLUSIVE_AREA_XCP_INTERNALS()


#endif 



