

#ifndef SCHM_CAN_17_MCMCAN_H
#define SCHM_CAN_17_MCMCAN_H

#include "Os.h"



#define SchM_Enter_Can_17_McmCan_CanDisInt() 
#define SchM_Exit_Can_17_McmCan_CanDisInt()    
#define SchM_Enter_Can_17_McmCan_CanEnInt()     
#define SchM_Exit_Can_17_McmCan_CanEnInt()    
#define SchM_Enter_Can_17_McmCan_CanWrMO()    
#define SchM_Exit_Can_17_McmCan_CanWrMO()    

#endif /* SCHM_CAN_17_MCMCAN_H */
