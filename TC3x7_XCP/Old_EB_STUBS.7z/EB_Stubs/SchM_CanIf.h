#ifndef SCHM_CANIF_H
#define SCHM_CANIF_H

#include "Os.h"



#define SchM_Enter_CanIf_SCHM_CANIF_EXCLUSIVE_AREA_0()
#define SchM_Exit_CanIf_SCHM_CANIF_EXCLUSIVE_AREA_0()    



#endif


