#ifndef SCHM_COMM_H
#define SCHM_COMM_H


#include "Os.h"

#define SchM_Enter_ComM_SCHM_COMM_EXCLUSIVE_AREA_0()  
#define SchM_Exit_ComM_SCHM_COMM_EXCLUSIVE_AREA_0()   


#endif


