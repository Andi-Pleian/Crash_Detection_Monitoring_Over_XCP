#ifndef SCHM_CANSM_H
#define SCHM_CANSM_H

#include "Os.h"

#define  SchM_Enter_CanSM_SCHM_CANSM_EXCLUSIVE_AREA_0()
#define  SchM_Exit_CanSM_SCHM_CANSM_EXCLUSIVE_AREA_0()


#endif 



